import {
  require_react_dom
} from "./chunk-ZZLBGYQN.js";
import "./chunk-65KY755N.js";
import "./chunk-V4OQ3NZ2.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
