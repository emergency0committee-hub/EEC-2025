import {
  Headers,
  Request,
  Response,
  browser_default,
  fetch,
  init_browser
} from "./chunk-C5A7FNJB.js";
import "./chunk-V4OQ3NZ2.js";
init_browser();
export {
  Headers,
  Request,
  Response,
  browser_default as default,
  fetch
};
//# sourceMappingURL=browser-VLKRZ7RP.js.map
