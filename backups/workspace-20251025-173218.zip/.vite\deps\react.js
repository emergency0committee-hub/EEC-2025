import {
  require_react
} from "./chunk-65KY755N.js";
import "./chunk-V4OQ3NZ2.js";
export default require_react();
//# sourceMappingURL=react.js.map
